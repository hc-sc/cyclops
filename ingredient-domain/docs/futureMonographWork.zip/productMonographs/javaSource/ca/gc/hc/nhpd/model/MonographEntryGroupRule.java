package ca.gc.hc.nhpd.model;

import ca.gc.hc.nhpd.model.support.EqualsEvaluator;
import ca.gc.hc.nhpd.model.support.Evaluator;
import ca.gc.hc.nhpd.model.support.GreaterThanEvaluator;
import ca.gc.hc.nhpd.model.support.LessThanEvaluator;
import java.util.Set;
import org.apache.log4j.Logger;

/*******************************************************************************
 * This class represents a rule that a MonographEntryGroup applies to a Product.
 * The isMatch() is called to evaluate whether the rule applies (i.e. if the
 * values of the result properties are applicable).
 * Note that, so far, matching logic is all based on MonographEntry counts.
 */
public class MonographEntryGroupRule extends PersistentObject {
    public static final String EQUALS_OPERATOR = "=";
    public static final String GREATER_THAN_OPERATOR = ">";
    public static final String LESS_THAN_OPERATOR = "<";
    private static final Logger log = Logger.getLogger(MonographEntryGroupRule
                                                       .class);

    private transient Evaluator countEvaluator;
    private String countOperator;
    private int selectedEntryCount;
    //results
    private Set<MonographDose> combinedDoses;
    private Set<DosageForm> dosageForms;
    private String errorMessageE;
    private String errorMessageF;
    private Set<MonographDuration> monographDurations;
    private Set<GenericText> recommendedUses;
    private Set<SubPopulation> subPopulations;
    
    /**
     * Gets the minimum and maximum dose information by SubPopulation for all
     * of the Ingredients (MonographEntries) that are part of this group
     * combined.
     * @return the dose information for all of this group's Ingredients combined
     *         when used in a Product.
     * @see #setCombinedDoses()
     */
    public Set<MonographDose> getCombinedDoses() {
        return combinedDoses;
    }
    
    /**
     * Sets the minimum and maximum dose information by SubPopulation for all
     * of the Ingredients (MonographEntries) that are part of this group
     * combined. For Hibernate use.
     * @param aSet the dose information for all of this group's Ingredients
     *        combined when used in a Product.
     * @see #getCombinedDoses()
     */
    public void setCombinedDoses(Set<MonographDose> aSet) {
        combinedDoses = aSet;
    }
    
    /**
     * Gets the equality operator used to evaluate the number of Ingredients
     * (MonographEntries) that are part of a Product that is being evaluated.
     * @return the class constant that represents the equality operator used to
     *         evaluate the number of Ingredients used in a Product.
     * @see #setCountOperator()
     */
    public String getCountOperator() {
        return countOperator;
    }

    /**
     * Sets the equality operator used to evaluate the number of Ingredients
     * (MonographEntries) that are part of a Product that is being evaluated.
     * For Hibernate use.
     * @param aString the class constant that represents the equality operator
     *        used to evaluate the number of Ingredients used in a Product.
     * @see #getCountOperator()
     */
    public void setCountOperator(String aString) {
        countOperator = aString;
        countEvaluator = getEvaluatorForOperator(countOperator);
    }

    /**
     * Gets the set of dosage forms that are valid if this rule applies. This is
     * a subset of those that would otherwise be available for this monograph.
     * @return a set of valid dosage forms.
     * @see #setDosageForms()
     */
    public Set<DosageForm> getDosageForms() {
        return dosageForms;
    }

    /**
     * Sets the set of dosage forms that are valid if this rule applies. This is
     * a subset of those that would otherwise be available for this monograph.
     * For Hibernate use.
     * @param aSet a set of valid dosage forms.
     * @see #getDosageForms()
     */
    public void setDosageForms(Set<DosageForm> aSet) {
        dosageForms = aSet;
    }

    /**
     * Gets the error message that should be displayed if this rule applies in
     * the language appropriate for the Locale.
     * @return the locale-specific source notes.
     */
    public String getErrorMessage() {
        if (isLanguageFrench()) {
            return getErrorMessageF();
        }
        return getErrorMessageE();
    }

    /**
     * Gets the error message that should be displayed if this rule applies (in
     * English).
     * @return the error message that should be displayed if this rule applies
     *         (in English).
     * @see #setErrorMessageE()
     */
    public String getErrorMessageE() {
        return errorMessageE;
    }

    /**
     * Sets the error message that should be displayed if this rule applies (in
     * English). For Hibernate use.
     * @param aString the error message that should be displayed if this rule
     *        applies (in English).
     * @see #getErrorMessageE()
     */
    public void setErrorMessageE(String aString) {
        errorMessageE = aString;
    }

    /**
     * Gets the error message that should be displayed if this rule applies (in
     * French).
     * @return the error message that should be displayed if this rule applies
     *         (in French).
     * @see #setErrorMessageF()
     */
    public String getErrorMessageF() {
        return errorMessageF;
    }

    /**
     * Sets the error message that should be displayed if this rule applies (in
     * French). For Hibernate use.
     * @param aString the error message that should be displayed if this rule
     *        applies (in French).
     * @see #getErrorMessageF()
     */
    public void setErrorMessageF(String aString) {
        errorMessageF = aString;
    }

    /**
     * Gets the collection of durations that the product must be restricted to
     * if this rule applies. In some cases, these are for specific uses.
     * @return  a set of durations that the product must be restricted to.
     * @see #setMonographDurations()
     */
    public Set<MonographDuration> getMonographDurations() {
        return monographDurations;
    }

    /**
     * Sets the collection of durations that the product must be restricted to
     * if this rule applies. In some cases, these are for specific uses.
     * For Hibernate use.
     * @param aSet  a set of durations that the product must be restricted to.
     * @see #getMonographDurations()
     */
    public void setMonographDurations(Set<MonographDuration> aSet) {
        monographDurations = aSet;
    }

    /**
     * Gets the set of additional recommended uses that are valid if this rule
     * applies. These may be added to those that would otherwise be available
     * for this monograph.
     * @return the set of statements of what a Product could be used for.
     * @see #setRecommendedUses()
     */
    public Set<GenericText> getRecommendedUses() {
        return recommendedUses;
    }

    /**
     * Sets the set of additional recommended uses that are valid if this rule
     * applies. These may be added to those that would otherwise be available
     * for this monograph. For Hibernate use.
     * @param aSet the set of statements of what a Product could be used for.
     * @see #getRecommendedUses()
     */
    public void setRecommendedUses(Set<GenericText> aSet) {
        recommendedUses = aSet;
    }
    
    /**
     * Gets the number of MonographEntries that a Product is compared against
     * when evaluating this rule.
     * @return the number of Ingredients (MonographEntries) that are part of a
     *         Product for it to match this rule using the specified operator.
     * @see #setSelectedEntryCount()
     */
    public int getSelectedEntryCount() {
        return selectedEntryCount;
    }

    /**
     * Sets the number of MonographEntries that a Product is compared against
     * when evaluating this rule. For Hibernate use.
     * @param anInt the number of Ingredients (MonographEntries) that are part
     *        of a Product for it to match this rule using the specified
     *        operator.
     * @see #getSelectedEntryCount()
     */
    public void setSelectedEntryCount(int anInt) {
        selectedEntryCount = anInt;
    }

    /**
     * Gets the collection of subPopulations that the product must be restricted
     * to if this rule applies.
     * @return the Set of subPopulations that a product must be restricted to if
     *         this rule applies.
     * @see #setSubPopulations()
     */
    public Set<SubPopulation> getSubPopulations() {
        return subPopulations;
    }

    /**
     * Sets the collection of subPopulations that the product must be restricted
     * to if this rule applies. For Hibernate use.
     * @param aSet the Set of subPopulations that a product must be restricted
     *        to if this rule applies.
     * @see #getSubPopulations()
     */
    public void setSubPopulations(Set<SubPopulation> aSet) {
        subPopulations = aSet;
    }

    /**
     * Called to determine whether this rule applies.
     * @param numberOfEntries the number of MonographEntries from the Group this
     *        is for that are used in the Product.
     * @return true if this rule applies given the passed value.
     */
    public boolean isMatch(int numberOfEntries) {
        if (countEvaluator != null) {
            return countEvaluator.evaluate(numberOfEntries, selectedEntryCount);
        }
        log.error("Rule matching has failed since no valid count operator was"
                  + " specified.");
        return false;
    }

    /**
     * This provides a list of the instance variable values for this object, and
     * is called by the PersistentObject's toString(). Intended to provide
     * useful debugging information. Subclasses should override this and add
     * their values to the end.
     */
    @Override
    public String getValuesAsString(){
        StringBuilder buffer = new StringBuilder();
        boolean isFirstItem;

        buffer.append(super.getValuesAsString());
        buffer.append(", countOperator: ");
        buffer.append(getCountOperator());
        buffer.append(", selectedEntryCount: ");
        buffer.append(getSelectedEntryCount());
        buffer.append(", combinedDoses: ");
        buffer.append(getCombinedDoses());
        buffer.append(", dosageForms: ");
        buffer.append(getDosageForms());
        buffer.append(", errorMessageE: ");
        buffer.append(getErrorMessageE());
        buffer.append(", monographDurations: ");
        buffer.append(getMonographDurations());
        buffer.append(", recommendedUses: ");
        buffer.append(getRecommendedUses());
        buffer.append(", subPopulations: ");
        if (getSubPopulations() != null){
            isFirstItem = true;
            buffer.append("[");
            for (SubPopulation subPopulation : getSubPopulations()) {
                if (isFirstItem) {
                    isFirstItem = false;
                } else {
                    buffer.append(", ");
                }
                buffer.append(subPopulation.getName());
            }
            buffer.append("]");
        } else {
            buffer.append("null");
        }

        return buffer.toString();
    }

    //~ private ----------------------------------------------------------------
    /**
     * Gets the evaluator that corresponds to the passed equality operator. This
     * is used to do the evaluation at run time.
     * @param operator the class constant that represents the evaluator.
     * @return the evaluator equivalent to the passed operator class constant.
     *         Null if the passed String is not a recognized constant (also logs
     *         an error).
     */
    private Evaluator getEvaluatorForOperator(String operator) {
        if (EQUALS_OPERATOR.equals(operator)) {
            return new EqualsEvaluator();
        } else if (GREATER_THAN_OPERATOR.equals(operator)) {
            return new GreaterThanEvaluator();
        } else if (LESS_THAN_OPERATOR.equals(operator)) {
            return new LessThanEvaluator();
        }
        log.error("Invalid operator specified: '" + operator + "'.");
        return null;
    }
}
