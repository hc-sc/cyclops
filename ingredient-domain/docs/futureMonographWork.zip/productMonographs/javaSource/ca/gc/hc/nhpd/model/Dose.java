package ca.gc.hc.nhpd.model;

/*******************************************************************************
 * The Dose defines the quantity and frequency of an ingredient or product.
 * These are almost always expressed in the context of a subPopulation.
 */
public class Dose extends PersistentObject {
    private Float doseMaximum;
    private Float doseMinimum;
    private Units doseUnits;
    private int frequencyMaximum;
    private int frequencyMinimum;
    private Units frequencyUnits;
    private SubPopulation subPopulation;

    /**
     * Getter for the maximum dose defined by this Dose object.
     * @return  the maximum dose defined by this Dose object.
     * @see     #setDoseMaximum()
     */
    public Float getDoseMaximum() {
        return doseMaximum;
    }

    /**
     * Getter for the minimum dose defined by this Dose object.
     * @return  the minimum dose defined by this Dose object.
     * @see     #setDoseMinimum()
     */
    public Float getDoseMinimum() {
        return doseMinimum;
    }

    /**
     * Getter for the units defining the minimum and maximum dose in this
     * Dose object.
     * @return  the dose units qualifying the minimum and maximum dose values
     *          found in this Dose object.
     * @see     #setDoseUnits()
     */
    public Units getDoseUnits() {
        return doseUnits;
    }

    /**
     * Getter for the maximum frequency defined by this Dose object. The maximum
     * frequency helps qualify the period in which the dose can be taken.
     * 
     * <p>For example, dose X can be taken from 3 to 5 times per day. In this
     * case, the 5 would represent the maximum frequency.
     * @return  the maximum frequency defined by this Dose object.
     * @see     #setFrequencyMaximum()
     */
    public int getFrequencyMaximum() {
        return frequencyMaximum;
    }

    /**
     * Getter for the minimum frequency defined by this Dose object. The minimum
     * frequency helps qualify the period in which the dose can be taken.
     * 
     * <p>For example, dose X can be taken from 3 to 5 times per day. In this
     * case, the 3 would represent the minimum frequency.
     * @return  the minimum frequency defined by this Dose object.
     * @see     #setFrequencyMinimum()
     */
    public int getFrequencyMinimum() {
        return frequencyMinimum;
    }

    /**
     * Getter for the frequency units defining the minimum and maximum frequency
     * in this Dose object. In the future, we should perhaps implement a
     * validation that would ensure that the frequency and dose information
     * would fall within the restriction available for any given ingredient.
     *
     * <p>For example, dose X can be taken from 3 to 5 times per day. In this
     * case, the "day" would represent the qualifying units.
     * @return  the frequency units qualifying the minimum and maximum frequency
     *          values found in this Dose object.
     * @see     #setFrequencyUnits()
     */
    public Units getFrequencyUnits() {
        return frequencyUnits;
    }

    /**
     * Getter that returns the target sub-population associated with this dose.
     * The default value should be an 'adult'.
     * @return  the set of SubPopulation for this Dose object.
     * @see     #setSubPopulation()
     */
    public SubPopulation getSubPopulation() {
        return subPopulation;
    }

    /**
     * Sets the maximum dose for this Dose.
     * @param  newVal  the maximum dose for this Dose.
     * @see    #getDoseMaximum()
     */
    public void setDoseMaximum(Float newVal) {
        doseMaximum = newVal;
    }

    /**
     * Sets the minimum dose for this Dose.
     * @param  newVal  the minimum dose for this Dose.
     * @see    #getDoseMinimum()
     */
    public void setDoseMinimum(Float newVal) {
        doseMinimum = newVal;
    }

    /**
     * Sets the dosage units qualifying the minimum and maximum dose for this
     * Dose.
     * @param  newVal  the dosage units that qualify the minimum and maximum
     *                 dose.
     * @see    #getDoseUnits()
     */
    public void setDoseUnits(Units newVal) {
        doseUnits = newVal;
    }

    /**
     * Sets the maximum frequency for this Dose.
     * @param  newVal  the maximum frequency for this Dose.
     * @see    #getFrequencyMaximum()
     */
    public void setFrequencyMaximum(int newVal) {
        frequencyMaximum = newVal;
    }

    /**
     * Sets the minimum frequency for this Dose.
     * @param  newVal  the minimum frequency for this Dose.
     * @see    #getFrequencyMinimum()
     */
    public void setFrequencyMinimum(int newVal) {
        frequencyMinimum = newVal;
    }

    /**
     * Sets the frequency units qualifying the minimum and maximum dose for this
     * Dose.
     * @param  newVal  the frequency units that qualify the minimum and maximum
     *                 dose.
     * @see    #getFrequencyUnits()
     */
    public void setFrequencyUnits(Units newVal) {
        frequencyUnits = newVal;
    }

    /**
     * Sets the sub-population information for this dose.
     * @param  newVal  the sub-population being targeted by this dose.
     * @see    #getSubPopulation()
     */
    public void setSubPopulation(SubPopulation newVal) {
        subPopulation = newVal;
    }

    /***************************************************************************
     * This provides a list of the instance variable values for this object, and
     * is called by the PersistentObject's toString(). Intended to provide
     * useful debugging information. Subclasses should override this and add
     * their values to the end.
     */
    @Override
    public String getValuesAsString(){
        StringBuilder buffer = new StringBuilder();

        buffer.append(super.getValuesAsString());
        buffer.append(", doseMaximum: ");
        buffer.append(getDoseMaximum());
        buffer.append(", doseMinimum: ");
        buffer.append(getDoseMinimum());
        buffer.append(", doseUnits: ");
        if (getDoseUnits() != null){
            buffer.append(getDoseUnits().getName());
        } else {
            buffer.append("null");
        }
        buffer.append(", frequencyMaximum: ");
        buffer.append(getFrequencyMaximum());
        buffer.append(", frequencyMinimum: ");
        buffer.append(getFrequencyMinimum());
        buffer.append(", frequencyUnits: ");
        if (getFrequencyUnits() != null){
            buffer.append(getFrequencyUnits().getName());
        } else {
            buffer.append("null");
        }
        buffer.append(", subPopulation: ");
        if (getSubPopulation() != null){
            buffer.append(getSubPopulation().getName());
        } else {
            buffer.append("null");
        }

        return buffer.toString();
    }
}
