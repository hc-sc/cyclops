package ca.gc.hc.nhpd.model;

import java.text.DecimalFormat;

/*******************************************************************************
 * The MonographSubingredientDose defines the quanitity and frequency of a
 * subIngredient when specifically defined in the Monograph. Normally dose is 
 * only defined by a MonographDose at the ingredient level, but on some occasions
 * this level of detail is also specified. <br/>
 *
 * The sub-ingredient relationship to the main ingredient must already be defined
 * in the ingredients model for this object to be valid. <br/>
 *
 * Also, the maximum and minimum doses should fall within the range defined for
 * the sub-ingredient.
 */
public class MonographSubIngredientDose extends PersistentObject 
										implements Comparable {
    private static final String CHAR_DASH="-";
    private static final String COMMA_SPACE=", ";
    private static final String CHAR_SPACE=" ";
    private static final String FREQUENCY_QUALIFIER="x/";
     
    //~ Instance fields --------------------------------------------------------
    //used primarily for loading
    private String code;    
        
    //parent MonographDoses.  Only used in loading    
    //private Set<MonographDose> monographDoses;
   
    private Dose dose;
	private RestrictionType restrictionType;
    private MonographSubIngredientCombination subIngredientCombination;

    //~ public -----------------------------------------------------------------

    /**
     * Compares this object with the specified object for equality and for
     * order. Returns a negative integer, zero, or a positive integer as this
     * object is less than, equal to, or greater than the specified object.
     *
     * @param   o  the object to compare this to.
     *
     * @return  a comparator flag qualifying equalify and order
     *
     * @throws  ClassCastException  when the object provided is of the wrong
     *                              type
     */
    public int compareTo(Object o) throws ClassCastException {

		try {

        if (o == null) {
            return -1;
        }

        // First compare on the SubIngredient (if different)
        if (getSubIngredientCombination() != null && 
          ((MonographSubIngredientDose)o).getSubIngredientCombination() != null) { 
        	int compareCode = getSubIngredientCombination()
        		.compareTo(((MonographSubIngredientDose) o).getSubIngredientCombination());
        	if (compareCode != 0) {
        		return compareCode;
        	}
        }

        // Compare on the Min Dose (if different)
        Float passedDoseMinimum = ((MonographSubIngredientDose) o).getDose().getDoseMinimum();
        if (dose.getDoseMinimum() != null && passedDoseMinimum != null &&
            !dose.getDoseMinimum().equals(passedDoseMinimum) ) {
            return dose.getDoseMinimum().compareTo(passedDoseMinimum);
        }
        //lets equate zero to null (not provided)
        if (dose.getDoseMinimum() == null && 
            passedDoseMinimum != null && passedDoseMinimum.floatValue() != 0f) {
            return 1;
        }
        if (dose.getDoseMinimum() != null && 
            (passedDoseMinimum == null || passedDoseMinimum.floatValue() == 0f)) {
            return -1;
        }

        // Then compare on the Max Dose (if different)
        Float passedDoseMaximum = ((MonographSubIngredientDose) o).getDose().getDoseMaximum();
        if (dose.getDoseMaximum() != null && passedDoseMaximum != null &&
            !dose.getDoseMaximum().equals(passedDoseMaximum) ) {
            return dose.getDoseMaximum().compareTo(passedDoseMaximum);
        }
        //lets equate zero to null (not provided)
        if (dose.getDoseMaximum() == null && 
            passedDoseMaximum != null && passedDoseMaximum.floatValue() != 0f) {
            return 1;
        }
        if (dose.getDoseMinimum() != null && 
            (passedDoseMaximum == null || passedDoseMaximum.floatValue() == 0f)) {
            return -1;
        }


        } catch ( Exception e ) {
            e.printStackTrace();
        }

        //finally, compare on the code.
		return getCode().compareTo(((MonographSubIngredientDose) o).getCode());
    }

    /**
     * Getter for the dose.
     *
     * @return  the dose for this MonographSubIngredientDose.
     *
     * @see     #setDose()
     */
    public Dose getDose() {

        return dose;
    }

    /**
     * Getter for the sub-ingredient. The sub-ingredient combination is the
     * object being qualified by the MonographSubIngredientDose object.
     * @return the sub-ingredient combination used by this
     *         MonographSubIngredientDose object.
     * @see    #setSubIngredientCombination()
     */
    public MonographSubIngredientCombination getSubIngredientCombination() {
        return subIngredientCombination;
    }

    
	public RestrictionType getRestrictionType() {
		return restrictionType;
	}

    /**
     * This provides a list of the instance variable values for this object, and
     * is called by the PersistentObject's toString(). Intended to provide
     * useful debugging information. Over-ridden to add additional values to the
     * end.
     *
     * @return  this object as a string value
     */
    @Override
    public String getValuesAsString() {
        StringBuffer buffer = new StringBuffer();

        buffer.append(super.getValuesAsString());
        buffer.append(", subIngredientCombination: ");
        buffer.append(getSubIngredientCombination());
        buffer.append(", dose: ");
        buffer.append(getDose());
        buffer.append(", restrictionType: ");
        if (getRestrictionType() != null){
            buffer.append(getRestrictionType().getName());
        } else {
            buffer.append("null");
        }

        return buffer.toString();
    }

    /**
     * Sets the dose for this object.
     *
     * @param  newVal  the dose
     *
     * @see    #getDose()
     */
    public void setDose(Dose newVal) {
        dose = newVal;
    }

    /**
     * Sets the qualifying sub-ingredient combination for which this object is
     * being created.
     * @param newVal the sub-ingredient combination being qualified by this
     *                 object.
     * @see   #getSubIngredientCombination()
     */
    public void setSubIngredientCombination(
                MonographSubIngredientCombination newVal) {
        subIngredientCombination = newVal;
    }

    /***************************************************************************
     */
	public void setRestrictionType(RestrictionType newVal) {
		restrictionType = newVal;
	}

    /***************************************************************************
     */
    //TODO consider refactoring into another object
    public String getQuantityForDisplay() {
        
        //might just be a ratio we need.
    	if ((dose.getDoseMinimum() == null || dose.getDoseMinimum().floatValue() == 0f) &&
        	(dose.getDoseMaximum() == null || dose.getDoseMaximum().floatValue() == 0f)) {
        	return "";
        }
        	
    	// Units must be present to display any value.  If not available, then return a null.
        if ( getDose().getDoseUnits() == null ) { 
            return "";
        }
        
        DecimalFormat twoPlaces = new DecimalFormat("0.####");
        StringBuffer output = new StringBuffer();

        
        //both doses the same - display single dose
        if ( dose.getDoseMinimum() != null && dose.getDoseMaximum() != null && 
        	 dose.getDoseMinimum().equals(dose.getDoseMaximum())) {
        	output.append( twoPlaces.format(dose.getDoseMinimum()) );
        } 
        //min-max dose
        else if ( dose.getDoseMinimum() != null && dose.getDoseMaximum() != null ) {
        	output.append( twoPlaces.format(dose.getDoseMinimum()) + CHAR_DASH + twoPlaces.format(dose.getDoseMaximum()) );
        } 
        //only min dose
        else if ( dose.getDoseMinimum() != null ) {
        	if (isLanguageFrench()) 
        		output.append(MonographDose.INCLUDING_F);
			else
				output.append(MonographDose.INCLUDING_E);
        	output.append( twoPlaces.format(dose.getDoseMinimum()) );
        }
        //only max dose
        else if ( dose.getDoseMaximum() != null ) {
        	if (isLanguageFrench()) 
        		output.append(" un maximum de ");
			else
				output.append(" no more than ");
        	output.append( twoPlaces.format(dose.getDoseMaximum()) );
        }
          
        // Dose Units
        if ( getDose().getDoseUnits() != null ) {
            output.append( CHAR_SPACE + getDose().getDoseUnits().getName());
        }
         
        return output.toString();
    }

    /***************************************************************************
     */
    //TODO consider refactoring into another object
    public String getFrequencyForDisplay() {
        if ( getDose().getFrequencyMinimum() == 0 && getDose().getFrequencyMaximum() == 0 ) {
            return null;
        }
        StringBuffer output = new StringBuffer();
        
        if ( getDose().getFrequencyMinimum() != 0 
             && getDose().getFrequencyMaximum() != 0 
             && getDose().getFrequencyMinimum() != getDose().getFrequencyMaximum()) {
             output.append( getDose().getFrequencyMinimum() + CHAR_DASH + getDose().getFrequencyMaximum() );
        } else if ( getDose().getFrequencyMinimum() != 0 
             && getDose().getFrequencyMinimum() != getDose().getFrequencyMaximum()) {
             output.append( getDose().getFrequencyMinimum() );
        } else if ( getDose().getFrequencyMaximum() != 0 ) {
             output.append( getDose().getFrequencyMaximum() );
        }
        // Frequency Units
        if ( getDose().getFrequencyUnits() != null ) {
            output.append( FREQUENCY_QUALIFIER + getDose().getFrequencyUnits().getName().toLowerCase());
        }
        return output.toString();
        
    }

    /***************************************************************************
     */
    //TODO consider refactoring into another object
    public String getValueForMonographDisplay() {
        StringBuffer output = new StringBuffer();
        //output.append("TODO (PreparationGroup): ");
        /*
        if ( getPreparationType() != null ) {
            output.append( getPreparationType().getName() + COLON_SPACE );
        } else if ( getPreparationTypeGroup() != null ) {
            output.append( getPreparationTypeGroup().getName() + COLON_SPACE );
        }
        */
        
        // Minimum / Maximum Dose
        if ( getDose().getDoseMinimum() != null && getDose().getDoseMaximum() != null 
                        && getDose().getDoseMinimum().equals(getDose().getDoseMaximum())) {
                    output.append( getDose().getDoseMinimum() );
                } else if ( getDose().getDoseMinimum() != null && getDose().getDoseMaximum() != null ) {
                    output.append( getDose().getDoseMinimum() + CHAR_DASH + getDose().getDoseMaximum() );
                } else if ( getDose().getDoseMinimum() != null ) {
                    output.append( getDose().getDoseMinimum() );
                } else if ( getDose().getDoseMaximum() != null ) {
                    output.append( getDose().getDoseMaximum() );
                }
                // Dose Units
        if ( getDose().getDoseUnits() != null ) {
            output.append( CHAR_SPACE + getDose().getDoseUnits().getCode());
        }
        
        if ( getSubIngredientCombination() != null) {
            if ( getSubIngredientCombination().getPrimarySubIngredient() != null 
                && getSubIngredientCombination().getPrimarySubIngredient().getIngredient() != null
                && getSubIngredientCombination().getPrimarySubIngredient().getIngredient().getAuthorizedName() != null) {
                output.append( " of " + getSubIngredientCombination().getPrimarySubIngredient().getIngredient().getAuthorizedName());

                if ( getSubIngredientCombination().getSecondarySubIngredient() != null 
                        && getSubIngredientCombination().getSecondarySubIngredient().getIngredient() != null
                        && getSubIngredientCombination().getSecondarySubIngredient().getIngredient().getAuthorizedName() != null) {
                        output.append( " and " + getSubIngredientCombination().getSecondarySubIngredient().getIngredient().getAuthorizedName());
                    }
            }
        }
        
        // Append a comma space.
        output.append( COMMA_SPACE );
        
//      Minimum / Maximum Frequency
             if ( getDose().getFrequencyMinimum() != 0 
                 && getDose().getFrequencyMaximum() != 0 
                 && getDose().getFrequencyMinimum() != getDose().getFrequencyMaximum()) {
                 output.append( getDose().getFrequencyMinimum() + CHAR_DASH + getDose().getFrequencyMaximum() );
             } else if ( getDose().getFrequencyMinimum() != 0 
                 && getDose().getFrequencyMinimum() != getDose().getFrequencyMaximum()) {
                 output.append( getDose().getFrequencyMinimum() );
             } else if ( getDose().getFrequencyMaximum() != 0 ) {
                 output.append( getDose().getFrequencyMaximum() );
             }
             // Frequency Units
             if ( getDose().getFrequencyUnits() != null ) {
                 output.append( FREQUENCY_QUALIFIER + getDose().getFrequencyUnits().getName().toLowerCase());
             }
        
        
        return output.toString();
    }

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}


}
