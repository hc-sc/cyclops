package ca.gc.hc.nhpd.model.support;

/*******************************************************************************
 * An object that evaluates the relationship between two numeric values and
 * prefers them to be of an equal value.
 */
public class EqualsEvaluator implements Evaluator {
    /**
     * Evaluates the passed arguments and returns true if they are equal.
     * @return true if the passed arguments are equal.
     */
    public boolean evaluate(int firstArg, int secondArg) {
        return firstArg == secondArg;
    }

    /**
     * Evaluates the passed arguments and returns true if they are equal.
     * @return true if the passed arguments are equal. Substitutes 0 for
     *         null arguments.
     */
    public boolean evaluate(Float firstArg, Float secondArg) {
        if (firstArg == null)
        {
            firstArg = Float.valueOf(0);
        }
        if (secondArg == null)
        {
            secondArg = Float.valueOf(0);
        }
        return firstArg.equals(secondArg);
    }
}
