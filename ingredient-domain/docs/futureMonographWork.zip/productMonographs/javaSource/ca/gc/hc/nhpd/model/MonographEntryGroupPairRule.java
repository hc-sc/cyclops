package ca.gc.hc.nhpd.model;

import java.util.Set;
import org.apache.log4j.Logger;
import ca.gc.hc.nhpd.model.support.EqualsEvaluator;
import ca.gc.hc.nhpd.model.support.Evaluator;
import ca.gc.hc.nhpd.model.support.GreaterThanEvaluator;
import ca.gc.hc.nhpd.model.support.LessThanEvaluator;

/*******************************************************************************
 * This class represents a rule that a MonographEntryGroupPair applies to a
 * Product.
 * The isMatch() is called to evaluate whether the rule applies (i.e. if the
 * values of the result properties are applicable).
 * Note that, so far, matching logic is all based on MonographEntry counts.
 */
public class MonographEntryGroupPairRule extends PersistentObject {
    public static final String EQUALS_OPERATOR = "=";
    public static final String GREATER_THAN_OPERATOR = ">";
    public static final String LESS_THAN_OPERATOR = "<";
    private static final Logger log = Logger.getLogger(
                                      MonographEntryGroupPairRule.class);

    private transient Evaluator firstEntryCountEvaluator;
    private String firstEntryCountOperator;
    private int firstSelectedEntryCount;
    private transient Evaluator secondEntryCountEvaluator;
    private String secondEntryCountOperator;
    private int secondSelectedEntryCount;
    //results
    private String errorMessageE;
    private String errorMessageF;
    private Set<GenericText> recommendedUses;
    private Set<RiskStatement> riskStatements;
    
    /**
     * Gets the equality operator used to evaluate the number of Ingredients
     * (MonographEntries) in the first group that are part of a Product that is
     * being evaluated.
     * @return the class constant that represents the equality operator used to
     *         evaluate the number of Ingredients in the first group that are 
     *         used in a Product.
     * @see #setFirstEntryCountOperator()
     */
    public String getFirstEntryCountOperator() {
        return firstEntryCountOperator;
    }

    /**
     * Sets the equality operator used to evaluate the number of Ingredients
     * (MonographEntries) in the first group that are part of a Product that is
     * being evaluated.
     * For Hibernate use.
     * @param aString the class constant that represents the equality operator
     *        used to evaluate the number of Ingredients in the first group that 
     *        are used in a Product.
     * @see #getFirstEntryCountOperator()
     */
    public void setFirstEntryCountOperator(String aString) {
        firstEntryCountOperator = aString;
        firstEntryCountEvaluator = getEvaluatorForOperator(
                                   firstEntryCountOperator);
    }
    
    /**
     * Gets the number of MonographEntries in the first group that a Product is
     * compared against when evaluating this rule.
     * @return the number of Ingredients (MonographEntries) in the first group
     *         that are part of a Product for it to match this rule using the
     *         specified operator.
     * @see #setFirstSelectedEntryCount()
     */
    public int getFirstSelectedEntryCount() {
        return firstSelectedEntryCount;
    }

    /**
     * Sets the number of MonographEntries in the first group that a Product is
     * compared against when evaluating this rule. For Hibernate use.
     * @param anInt the number of Ingredients (MonographEntries) in the first
     *        group that are part of a Product for it to match this rule using
     *        the specified operator.
     * @see #getFirstSelectedEntryCount()
     */
    public void setFirstSelectedEntryCount(int anInt) {
        firstSelectedEntryCount = anInt;
    }

    /**
     * Gets the error message that should be displayed if this rule applies in
     * the language appropriate for the Locale.
     * @return the locale-specific source notes.
     */
    public String getErrorMessage() {
        if (isLanguageFrench()) {
            return getErrorMessageF();
        }
        return getErrorMessageE();
    }

    /**
     * Gets the error message that should be displayed if this rule applies (in
     * English).
     * @return the error message that should be displayed if this rule applies
     *         (in English).
     * @see #setErrorMessageE()
     */
    public String getErrorMessageE() {
        return errorMessageE;
    }

    /**
     * Sets the error message that should be displayed if this rule applies (in
     * English). For Hibernate use.
     * @param aString the error message that should be displayed if this rule
     *        applies (in English).
     * @see #getErrorMessageE()
     */
    public void setErrorMessageE(String aString) {
        errorMessageE = aString;
    }

    /**
     * Gets the error message that should be displayed if this rule applies (in
     * French).
     * @return the error message that should be displayed if this rule applies
     *         (in French).
     * @see #setErrorMessageF()
     */
    public String getErrorMessageF() {
        return errorMessageF;
    }

    /**
     * Sets the error message that should be displayed if this rule applies (in
     * French). For Hibernate use.
     * @param aString the error message that should be displayed if this rule
     *        applies (in French).
     * @see #getErrorMessageF()
     */
    public void setErrorMessageF(String aString) {
        errorMessageF = aString;
    }

    /**
     * Gets the set of additional recommended uses that are valid if this rule
     * applies. These may be added to those that would otherwise be available
     * for this monograph.
     * @return the set of statements of what a Product could be used for.
     * @see #setRecommendedUses()
     */
    public Set<GenericText> getRecommendedUses() {
        return recommendedUses;
    }

    /**
     * Sets the set of additional recommended uses that are valid if this rule
     * applies. These may be added to those that would otherwise be available
     * for this monograph. For Hibernate use.
     * @param aSet the set of statements of what a Product could be used for.
     * @see #getRecommendedUses()
     */
    public void setRecommendedUses(Set<GenericText> aSet) {
        recommendedUses = aSet;
    }

    /**
     * Gets the set of additional risk statements that are required if this rule
     * applies. These should be added to those that would otherwise be required
     * for this monograph.
     * @return the set of statements of risks (cautions, warnings, etc.) that
     *         should be on the product label.
     * @see #setRiskStatements()
     */
    public Set<RiskStatement> getRiskStatements() {
        return riskStatements;
    }

    /**
     * Sets the set of additional risk statements that are required if this rule
     * applies. These should be added to those that would otherwise be required
     * for this monograph.
     * @param aSet the set of statements of risks (cautions, warnings, etc.)
     *        that should be on the product label.
     * @see #getRiskStatements()
     */
    public void setRiskStatements(Set<RiskStatement> aSet) {
        riskStatements = aSet;
    }
    
    /**
     * Gets the equality operator used to evaluate the number of Ingredients
     * (MonographEntries) in the second group that are part of a Product that is
     * being evaluated.
     * @return the class constant that represents the equality operator used to
     *         evaluate the number of Ingredients in the first group that are 
     *         used in a Product.
     * @see #setSecondEntryCountOperator()
     */
    public String getSecondEntryCountOperator() {
        return secondEntryCountOperator;
    }

    /**
     * Sets the equality operator used to evaluate the number of Ingredients
     * (MonographEntries) in the second group that are part of a Product that is
     * being evaluated.
     * For Hibernate use.
     * @param aString the class constant that represents the equality operator
     *        used to evaluate the number of Ingredients in the second group 
     *        that are used in a Product.
     * @see #getSecondEntryCountOperator()
     */
    public void setSecondEntryCountOperator(String aString) {
        secondEntryCountOperator = aString;
        secondEntryCountEvaluator = getEvaluatorForOperator(
                                    secondEntryCountOperator);
    }
    
    /**
     * Gets the number of MonographEntries in the second group that a Product is
     * compared against when evaluating this rule.
     * @return the number of Ingredients (MonographEntries) in the second group
     *         that are part of a Product for it to match this rule using the
     *         specified operator.
     * @see #setSecondSelectedEntryCount()
     */
    public int getSecondSelectedEntryCount() {
        return secondSelectedEntryCount;
    }

    /**
     * Sets the number of MonographEntries in the second group that a Product is
     * compared against when evaluating this rule. For Hibernate use.
     * @param anInt the number of Ingredients (MonographEntries) in the second
     *        group that are part of a Product for it to match this rule using
     *        the specified operator.
     * @see #getSecondEntryCount()
     */
    public void setSecondSelectedEntryCount(int anInt) {
        secondSelectedEntryCount = anInt;
    }

    /**
     * Called to determine whether this rule applies.
     * @param numberOfFirstEntries the number of MonographEntries from the first
     *        group this is for that are used in the Product.
     * @param numberOfSecondEntries the number of MonographEntries from the
     *        second group this is for that are used in the Product.
     * @return true if this rule applies given the passed value.
     */
    public boolean isMatch(int numberOfFirstEntries,
                           int numberOfSecondEntries) {
        if (firstEntryCountEvaluator != null 
            && secondEntryCountEvaluator != null) {
            return firstEntryCountEvaluator.evaluate(numberOfFirstEntries,
                                                     firstSelectedEntryCount)
                   && secondEntryCountEvaluator.evaluate(numberOfSecondEntries,
                                                         secondSelectedEntryCount);
        }
        log.error("Rule matching has failed since the first and/or second count"
                  + " operator was not specified.");
        return false;
    }

    /**
     * This provides a list of the instance variable values for this object, and
     * is called by the PersistentObject's toString(). Intended to provide
     * useful debugging information. Subclasses should override this and add
     * their values to the end.
     */
    @Override
    public String getValuesAsString(){
        StringBuilder buffer = new StringBuilder();

        buffer.append(super.getValuesAsString());
        buffer.append(", firstEntryCountOperator: ");
        buffer.append(getFirstEntryCountOperator());
        buffer.append(", firstSelectedEntryCount: ");
        buffer.append(getFirstSelectedEntryCount());
        buffer.append(", secondEntryCountOperator: ");
        buffer.append(getSecondEntryCountOperator());
        buffer.append(", secondSelectedEntryCount: ");
        buffer.append(getSecondSelectedEntryCount());
        buffer.append(", errorMessageE: ");
        buffer.append(getErrorMessageE());
        buffer.append(", recommendedUses: ");
        buffer.append(getRecommendedUses());
        buffer.append(", riskStatements: ");
        buffer.append(getRiskStatements());
        
        return buffer.toString();
    }

    //~ private ----------------------------------------------------------------
    /**
     * Gets the evaluator that corresponds to the passed equality operator. This
     * is used to do the evaluation at run time.
     * @param operator the class constant that represents the evaluator.
     * @return the evaluator equivalent to the passed operator class constant.
     *         Null if the passed String is not a recognized constant (also logs
     *         an error).
     */
    private Evaluator getEvaluatorForOperator(String operator) {
        if (EQUALS_OPERATOR.equals(operator)) {
            return new EqualsEvaluator();
        } else if (GREATER_THAN_OPERATOR.equals(operator)) {
            return new GreaterThanEvaluator();
        } else if (LESS_THAN_OPERATOR.equals(operator)) {
            return new LessThanEvaluator();
        }
        log.error("Invalid operator specified: '" + operator + "'.");
        return null;
    }
}
