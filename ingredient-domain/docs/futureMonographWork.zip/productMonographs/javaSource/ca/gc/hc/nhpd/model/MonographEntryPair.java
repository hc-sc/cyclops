package ca.gc.hc.nhpd.model;

import ca.gc.hc.nhpd.model.support.EqualsEvaluator;
import ca.gc.hc.nhpd.model.support.Evaluator;
import ca.gc.hc.nhpd.model.support.GreaterThanEvaluator;
import ca.gc.hc.nhpd.model.support.LessThanEvaluator;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import org.apache.log4j.Logger;

/*******************************************************************************
 * A class that contains a pair of MonographEntry objects together with their
 * business rules.
 * Used by product Monographs, these allow different rules to put restrictions
 * on Products based on what Ingredients (MonographEntries) are in them. These
 * contain two of the MonographEntries that make up the product Monograph.
 */
public class MonographEntryPair extends PersistentObject {
    public static final String BOTH_APPLICABILITY = "both";
    public static final String EITHER_APPLICABILITY = "either";
    public static final String FIRST_APPLICABILITY = "first";
    public static final String EQUALS_OPERATOR = "=";
    public static final String GREATER_THAN_OPERATOR = ">";
    public static final String LESS_THAN_OPERATOR = "<";
    private static final Logger log = Logger.getLogger(MonographEntryPair.class);

    private String applicability;
    private transient Map<SubPopulation, MonographDose[]> entryDosesBySubPopulation;
    private Set<MonographDose> firstEntryDoses;
    private transient Evaluator firstEntryEvaluator;
    private String firstEntryOperator;
    private MonographEntry firstMonographEntry;
    private Set<MonographDose> secondEntryDoses;
    private transient Evaluator secondEntryEvaluator;
    private String secondEntryOperator;
    private MonographEntry secondMonographEntry;
    //results
    private Set<RiskStatement> riskStatements;
    
    /**
     * Gets the applicability of the rules in this pair. When set to "both",
     * both of the MonographEntries in this pair must be present in the Product
     * for a match to continue in its evaluation. When set to "either", either
     * of the MonographEntries in this pair must be present in the Product. When
     * set to "first", the first of the MonographEntries in this pair must be
     * present in the Product. This must be populated.
     * @return the class constant that represents the applicability used to
     *         determine if matching is required.
     * @see #setApplicability()
     */
    public String getApplicability() {
        return applicability;
    }
    
    /**
     * Sets the applicability of the rules in this pair. When set to "both",
     * both of the MonographEntries in this pair must be present in the Product
     * for a match to continue in its evaluation. When set to "either", either
     * of the MonographEntries in this pair must be present in the Product. When
     * set to "first", the first of the MonographEntries in this pair must be
     * present in the Product. This must be populated. For Hibernate use.
     * @param aString the class constant that represents the applicability used
     *        to determine if matching is required.
     * @see #getApplicability()
     */
    public void setApplicability(String aString) {
        applicability = aString;
    }
    
    /**
     * Gets the Doses by SubPopulation used to evaluate the Product dose against.
     * Required if firstEntryOperator is populated.
     * Note that only doseMaximum comparison is supported at this time.
     * @return a Set of MonographDoses, one for each SubPopulation of interest.
     *         Missing SubPopulations are skipped during the evaluation process.
     * @see #setFirstEntryDoses()
     */
    public Set<MonographDose> getFirstEntryDoses() {
        return firstEntryDoses;
    }
    
    /**
     * Sets the Doses by SubPopulation used to evaluate the Product dose against.
     * Required if firstEntryOperator is populated.
     * Note that only doseMaximum comparison is supported at this time.
     * For Hibernate use.
     * @param aSet a Set of MonographDoses, one for each SubPopulation of
     *        interest. Missing SubPopulations are skipped during the evaluation
     *        process.
     * @see #getFirstEntryDoses()
     */
    public void setFirstEntryDoses(Set<MonographDose> aSet) {
        firstEntryDoses = aSet;
    }
    
    /**
     * Gets the equality operator used to evaluate the Product dose against
     * those in firstEntryDoses. If null, this comparison is skipped.
     * @return the class constant that represents the equality operator used to
     *         evaluate the doses used in a Product by SubPopulation.
     * @see #setFirstEntryOperator()
     */
    public String getFirstEntryOperator() {
        return firstEntryOperator;
    }
    
    /**
     * Sets the equality operator used to evaluate the Product dose against
     * those in firstEntryDoses. If null, this comparison is skipped.
     * For Hibernate use.
     * @param aString the class constant that represents the equality operator
     *        used to evaluate the doses used in a Product by SubPopulation.
     * @see #getFirstEntryOperator()
     */
    public void setFirstEntryOperator(String aString) {
        firstEntryOperator = aString;
        firstEntryEvaluator = getEvaluatorForOperator(firstEntryOperator);
    }
    
    /**
     * Gets the first of two MonographEntries that belong to this set.
     * @return the first of two MonographEntries that belong to this set.
     * @see setFirstMonographEntry()
     */
    public MonographEntry getFirstMonographEntry() {
        return firstMonographEntry;
    }
    
    /**
     * Sets the first of two MonographEntries that belong to this set.
     * For Hibernate use.
     * @param anEntry the first of two MonographEntries that belong to this set.
     * @see getFirstMonographEntry()
     */
    public void setFirstMonographEntry(MonographEntry anEntry) {
        firstMonographEntry = anEntry;
    }

    /**
     * Gets the set of additional risk statements that must be displayed on the
     * label if this rule applies. These are added to those that would otherwise
     * be applicable for this monograph.
     * @return the set of statements of risks associated to a Product.
     * @see #setRiskStatements()
     */
    public Set<RiskStatement> getRiskStatements() {
        return riskStatements;
    }

    /**
     * Sets the set of additional risk statements that must be displayed on the
     * label if this rule applies. These are added to those that would otherwise
     * be applicable for this monograph.
     * @param aSet the set of statements of risks associated to a Product.
     * @see #getRiskStatements()
     */
    public void setRiskStatements(Set<RiskStatement> aSet) {
        riskStatements = aSet;
    }
    
    /**
     * Gets the Doses by SubPopulation used to evaluate the Product dose against.
     * Required if secondEntryOperator is populated.
     * Note that only doseMaximum comparison is supported at this time.
     * @return a Set of MonographDoses, one for each SubPopulation of interest.
     *         Missing SubPopulations are skipped during the evaluation process.
     * @see #setSecondEntryDoses()
     */
    public Set<MonographDose> getSecondEntryDoses() {
        return secondEntryDoses;
    }
    
    /**
     * Sets the Doses by SubPopulation used to evaluate the Product dose against.
     * Required if secondEntryOperator is populated.
     * Note that only doseMaximum comparison is supported at this time.
     * For Hibernate use.
     * @param aSet a Set of MonographDoses, one for each SubPopulation of
     *        interest. Missing SubPopulations are skipped during the evaluation
     *        process.
     * @see #getSecondEntryDoses()
     */
    public void setSecondEntryDoses(Set<MonographDose> aSet) {
        secondEntryDoses = aSet;
    }
    
    /**
     * Gets the equality operator used to evaluate the Product dose against
     * those in secondEntryDoses. If null, this comparison is skipped.
     * @return the class constant that represents the equality operator used to
     *         evaluate the doses used in a Product by SubPopulation.
     * @see #setSecondEntryOperator()
     */
    public String getSecondEntryOperator() {
        return secondEntryOperator;
    }
    
    /**
     * Sets the equality operator used to evaluate the Product dose against
     * those in secondEntryDoses. If null, this comparison is skipped.
     * For Hibernate use.
     * @param aString the class constant that represents the equality operator
     *        used to evaluate the doses used in a Product by SubPopulation.
     * @see #getSecondEntryOperator()
     */
    public void setSecondEntryOperator(String aString) {
        secondEntryOperator = aString;
        secondEntryEvaluator = getEvaluatorForOperator(secondEntryOperator);
    }

    /**
     * Gets the second of two MonographEntries that belong to this set.
     * @return the second of two MonographEntries that belong to this set.
     * @see setSecondMonographEntry()
     */
    public MonographEntry getSecondMonographEntry() {
        return secondMonographEntry;
    }
    
    /**
     * Sets the second of two MonographEntries that belong to this set.
     * For Hibernate use.
     * @param anEntry the second of two MonographEntries that belong to this
     *        set.
     * @see getSecondMonographEntry()
     */
    public void setSecondMonographEntry(MonographEntry anEntry) {
        secondMonographEntry = anEntry;
    }

    /**
     * Called to determine whether the rules in this pair match the Product
     * being evaluated. If so, its results properties should be merged in
     * with those from other areas.
     * This compares the maximum doses by subPopulation. Note that all missing
     * entries are considered to have a value of 0 during this evaluation.
     * There is a logical "AND" between the first and second entries and a
     * logical "OR" between subPopulations.
     * @param selectedMonographEntries the set of MonographEntries associated
     *        with the Product being evaluated.
     * @param firstEntryDoses the set of Doses associated with the first
     *        Ingredient in the Product being evaluated.
     * @param secondEntryDoses the set of Doses associated with the second
     *        Ingredient in the Product being evaluated.
     * @return true if this rule applies given the passed values.
     */
    //TODO This does not currently support Units conversion
    public boolean isMatch(Set<MonographEntry> selectedMonographEntries,
                   Set<Dose> firstEntryDoses, Set<Dose> secondEntryDoses) {
        if (firstEntryEvaluator == null || secondEntryEvaluator == null) {
            log.error("Rule matching has failed since a first and/or second"
                      + " entry operator was not specified.");
            return false; 
        }
        if (isApplicable(selectedMonographEntries)) {
            Collection<MonographDose[]> dosePairs = 
                getEntryDosesBySubPopulation().values();
            Float firstEntryDoseMaximum;
            Float secondEntryDoseMaximum;

            for (MonographDose[] dosePair : dosePairs) {
                firstEntryDoseMaximum = null;
                secondEntryDoseMaximum = null;
                for (Dose firstEntryDose : firstEntryDoses) {
                    if (dosePair[0].getSubPopulation().equals(firstEntryDose
                                                       .getSubPopulation())) {
                        firstEntryDoseMaximum = firstEntryDose.getDoseMaximum();
                        break;
                    }
                }
                for (Dose secondEntryDose : secondEntryDoses) {
                    if (dosePair[0].getSubPopulation().equals(secondEntryDose
                                                       .getSubPopulation())) {
                        secondEntryDoseMaximum = secondEntryDose.getDoseMaximum();
                        break;
                    }
                }
                if (firstEntryEvaluator.evaluate(firstEntryDoseMaximum,
                                                 dosePair[0].getDose().getDoseMaximum())
                    && secondEntryEvaluator.evaluate(secondEntryDoseMaximum,
                                                     dosePair[1].getDose().getDoseMaximum())) {
                    return true;
                }
            }
        }
        return false; 
    }

    /**
     * This provides a list of the instance variable values for this object, and
     * is called by the PersistentObject's toString(). Intended to provide
     * useful debugging information. Subclasses should override this and add
     * their values to the end.
     */
    @Override
    public String getValuesAsString(){
        StringBuilder buffer = new StringBuilder();

        buffer.append(super.getValuesAsString());
        buffer.append(", firstMonographEntry: ");
        if (getFirstMonographEntry() != null){
            if (getFirstMonographEntry().getIngredient() != null) {
                buffer.append(getFirstMonographEntry().getIngredient().getAuthorizedName());
            } else {
                buffer.append("MonographEntry with no Ingredient");
            }
        } else {
            buffer.append("null");
        }
        buffer.append(", secondMonographEntry: ");
        if (getSecondMonographEntry() != null){
            if (getSecondMonographEntry().getIngredient() != null) {
                buffer.append(getSecondMonographEntry().getIngredient().getAuthorizedName());
            } else {
                buffer.append("MonographEntry with no Ingredient");
            }
        } else {
            buffer.append("null");
        }
        buffer.append(", applicability: ");
        buffer.append(getApplicability());
        buffer.append(", firstEntryOperator: ");
        buffer.append(getFirstEntryOperator());
        buffer.append(", firstEntryDoses: ");
        buffer.append(getFirstEntryDoses());
        buffer.append(", secondEntryOperator: ");
        buffer.append(getSecondEntryOperator());
        buffer.append(", secondEntryDoses: ");
        buffer.append(getSecondEntryDoses());
        buffer.append(", riskStatements: ");
        buffer.append(getRiskStatements());

        return buffer.toString();
    }

    //~ private ----------------------------------------------------------------
    /**
     * Gets the doses that are used to compare to the values in the
     * MonographEntries. This lazy loads a Map keyed on SubPopulation that
     * contains an array of doses where the first is firstEntryDose and the
     * second is the secondEntryDose. There is only a Map entry created if both
     * first and second doses are present for the SubPopulation. 
     * @return the doses that are used to compare to the values in the
     *         MonographEntries.
     */
    private Map<SubPopulation, MonographDose[]> getEntryDosesBySubPopulation() {
        if (entryDosesBySubPopulation == null) {
            MonographDose[] doses = new MonographDose[2];
            entryDosesBySubPopulation = new HashMap<SubPopulation,
                                                    MonographDose[]>();
            for (MonographDose firstEntryDose : firstEntryDoses) {
                for (MonographDose secondEntryDose : secondEntryDoses) {
                    if (firstEntryDose.getSubPopulation().equals(
                            secondEntryDose.getSubPopulation())) {
                        doses[0] = firstEntryDose;
                        doses[1] = secondEntryDose;
                        entryDosesBySubPopulation.put(
                                firstEntryDose.getSubPopulation(), doses);
                        break;
                    }
                }
 
            }
        }
        return entryDosesBySubPopulation;
    }

    /**
     * Gets the evaluator that corresponds to the passed equality operator. This
     * is used to do the evaluation at run time.
     * @param operator the class constant that represents the evaluator.
     * @return the evaluator equivalent to the passed operator class constant.
     *         Null if the passed String is not a recognized constant (also logs
     *         an error).
     */
    private Evaluator getEvaluatorForOperator(String operator) {
        if (EQUALS_OPERATOR.equals(operator)) {
            return new EqualsEvaluator();
        } else if (GREATER_THAN_OPERATOR.equals(operator)) {
            return new GreaterThanEvaluator();
        } else if (LESS_THAN_OPERATOR.equals(operator)) {
            return new LessThanEvaluator();
        }
        log.error("Invalid operator specified: '" + operator + "'.");
        return null;
    }

    /**
     * Called to determine whether the rules in this pair apply to the passed
     * MonographEntries.
     * @param selectedMonographEntries the set of MonographEntries associated
     *        with the Product being evaluated.
     * @return true if this rule applies given the passed entries.
     */
    private boolean isApplicable(Set<MonographEntry> selectedMonographEntries) {
        if (getApplicability() == null) {
            log.error("Applicability is null - this is not allowed. "
                      + "Treating it as not applicable.");
        }
        if (selectedMonographEntries.contains(getFirstMonographEntry())) {
            if (FIRST_APPLICABILITY == getApplicability() 
                || EITHER_APPLICABILITY == getApplicability()) {
                return true;
            }
            if (BOTH_APPLICABILITY == getApplicability()) {
                return selectedMonographEntries.contains(
                                                getSecondMonographEntry());
            }
        }
        if (EITHER_APPLICABILITY == getApplicability()) {
            return selectedMonographEntries.contains(getSecondMonographEntry());
        }
        return false;
    }
}
