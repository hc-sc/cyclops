package ca.gc.hc.nhpd.model.support;

/*******************************************************************************
 * An object that evaluates the relationship between two numeric values and
 * prefers the first to be greater than the second.
 */
public class GreaterThanEvaluator implements Evaluator {
    /**
     * Evaluates the passed arguments and returns true if the first is greater
     * than the second.
     * @return true if the first passed argument is greater than the second.
     */
    public boolean evaluate(int firstArg, int secondArg) {
        return firstArg > secondArg;
    }

    /**
     * Evaluates the passed arguments and returns true if the first is greater
     * than the second.
     * @return true if the first passed argument is greater than the second.
     *         Substitutes 0 for null arguments.
     */
    public boolean evaluate(Float firstArg, Float secondArg) {
        if (firstArg == null)
        {
            firstArg = Float.valueOf(0);
        }
        if (secondArg == null)
        {
            secondArg = Float.valueOf(0);
        }
        return firstArg.compareTo(secondArg) > 0;
    }
}
