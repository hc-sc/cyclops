package ca.gc.hc.nhpd.model;

/*
 * Only used by WebServices - not considered part of the model.
 */
public class MonographId {

	private String monographName;
	private Float version;
	private Long id;
	
	public String getMonographName() {
		return monographName;
	}
	public void setMonographName(String monographName) {
		this.monographName = monographName;
	}
	public Float getVersion() {
		return version;
	}
	public void setVersion(Float version) {
		this.version = version;
	}
	public Long getId() {
		return id; 
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	
}
