package ca.gc.hc.nhpd.model;

import java.util.HashSet;
import java.util.Set;

/*******************************************************************************
 * A class that contains a group of MonographEntry objects together with their
 * business rules.
 * Used by product Monographs, these allow different rules to put restrictions
 * on Products based on what Ingredients (MonographEntries) are in them. These
 * contain a subset of the MonographEntries that make up the product Monograph.
 */
public class MonographEntryGroup extends PersistentObject {
    private transient Set<MonographEntryGroupRule> matchedRules = 
                      new HashSet<MonographEntryGroupRule>();
    private Set<MonographEntryGroupRule> rules;
    private Set<MonographEntry> monographEntries;

    /**
     * Gets the set of MonographEntryGroupRules, if any, that match the set of
     * MonographEntries associated with the Product being evaluated. Will return
     * an empty Set if there aren't any that match.
     * Note that matchRules() must be called first.
     * @return the set of MonographEntryGroupRules that match the set of
     *         MonographEntries associated with a given Product.
     * @see matchRules()
     */
    public Set<MonographEntryGroupRule> getMatchedRules() {
        return matchedRules;
    }
    
    /**
     * Gets the set of MonographEntries that belong to this group.
     * @return the set of MonographEntries associated with this group.
     * @see setMonographEntries()
     */
    public Set<MonographEntry> getMonographEntries() {
        return monographEntries;
    }

    /**
     * Sets the set of MonographEntries that belong to this group.
     * For Hibernate use.
     * @param newVal the set of MonographEntries associated with this group.
     * @see getMonographEntries()
     */
    public void setMonographEntries(Set<MonographEntry> newVal) {
        monographEntries = newVal;
    }

    /**
     * Gets the set of MonographEntryGroupRules that belong to this group.
     * @return the set of MonographEntryGroupRules associated with this group.
     * @see setRules()
     */
    public Set<MonographEntryGroupRule> getRules() {
        return rules;
    }

    /**
     * Sets the set of MonographEntryGroupRules that belong to this group.
     * For Hibernate use.
     * @param newVal the set of MonographEntryGroupRules associated with this
     *        group.
     * @see getRules()
     */
    public void setRules(Set<MonographEntryGroupRule> aSet) {
        rules = aSet;
    }

    /**
     * Matches the rules against the passed parameters and populates matchedRules
     * with the result.
     * @param selectedMonographEntries the set of MonographEntries associated
     *        with the Product being evaluated.
     */
    public void matchRules(Set<MonographEntry> selectedMonographEntries) {
        if (rules != null && rules.size() > 0) {
            int numberSelected = 0;
            
            if (selectedMonographEntries != null 
                && selectedMonographEntries.size() > 0) {
                Set<MonographEntry> intersection = new HashSet<MonographEntry>(
                                                       getMonographEntries());

                intersection.retainAll(selectedMonographEntries);
                numberSelected = intersection.size();
            }
            
            matchedRules.clear();
            for (MonographEntryGroupRule rule : rules) {
                if (rule.isMatch(numberSelected)) {
                    matchedRules.add(rule);
                }
            }
        }
    }

    /**
     * This provides a list of the instance variable values for this object, and
     * is called by the PersistentObject's toString(). Intended to provide
     * useful debugging information. Subclasses should override this and add
     * their values to the end.
     */
    @Override
    public String getValuesAsString(){
        StringBuilder buffer = new StringBuilder();
        boolean isFirstItem;

        buffer.append(super.getValuesAsString());
        buffer.append(", monographEntries: ");
        if (getMonographEntries() != null){
            isFirstItem = true;
            buffer.append("[");
            for (MonographEntry entry : getMonographEntries()) {
                if (isFirstItem) {
                    isFirstItem = false;
                } else {
                    buffer.append(", ");
                }
                if (entry.getIngredient() != null) {
                    buffer.append(entry.getIngredient().getAuthorizedName());
                } else {
                    buffer.append("MonographEntry with no Ingredient");
                }
            }
            buffer.append("]");
        } else {
            buffer.append("null");
        }
        
        buffer.append(", rules: ");
        if (getRules() != null){
            isFirstItem = true;
            buffer.append("[");
            for (MonographEntryGroupRule rule : getRules()) {
                if (isFirstItem) {
                    isFirstItem = false;
                } else {
                    buffer.append(", ");
                }
                if (matchedRules.contains(rule)) {
                    buffer.append("MATCHED ");
                }
                buffer.append(rule.toString());
            }
            buffer.append("]");
        } else {
            buffer.append("null");
        }

        return buffer.toString();
    }
}
