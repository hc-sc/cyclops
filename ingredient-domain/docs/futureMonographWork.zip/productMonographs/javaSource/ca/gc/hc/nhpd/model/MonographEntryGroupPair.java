package ca.gc.hc.nhpd.model;

import java.util.HashSet;
import java.util.Set;

/*******************************************************************************
 * A class that contains a pair of MonographEntry object groups together with
 * their business rules.
 * Used by product Monographs, these allow different rules to put restrictions
 * on Products based on what Ingredients (MonographEntries) are in them. These
 * contain two subsets of the MonographEntries that make up the product
 * Monograph.
 */
public class MonographEntryGroupPair extends PersistentObject {
    private Set<MonographEntry> firstMonographEntryGroup;
    private transient Set<MonographEntryGroupPairRule> matchedRules = 
                      new HashSet<MonographEntryGroupPairRule>();
    private Set<MonographEntryGroupPairRule> rules;
    private Set<MonographEntry> secondMonographEntryGroup;

    /**
     * Gets the set of MonographEntryGroupPairRules, if any, that match the two
     * groups of MonographEntries associated with the Product being evaluated.
     * Will return an empty Set if there aren't any that match.
     * Note that matchRules() must be called first.
     * @return the set of MonographEntryGroupPairRules that match the two groups
     *         of MonographEntries associated with a given Product.
     * @see matchRules()
     */
    public Set<MonographEntryGroupPairRule> getMatchedRules() {
        return matchedRules;
    }
    
    /**
     * Gets the first group of MonographEntries to be compared.
     * @return the first group of MonographEntries to be compared.
     * @see setFirstMonographEntryGroup()
     */
    public Set<MonographEntry> getFirstMonographEntryGroup() {
        return firstMonographEntryGroup;
    }

    /**
     * Sets the first group of MonographEntries to be compared.
     * For Hibernate use.
     * @param newVal the first group of MonographEntries to be compared.
     * @see getFirstMonographEntryGroup()
     */
    public void setFirstMonographEntryGroup(Set<MonographEntry> newVal) {
        firstMonographEntryGroup = newVal;
    }

    /**
     * Gets the set of MonographEntryGroupPairRules that belong to this pair of
     * groups.
     * @return the set of MonographEntryGroupPairRules associated with this pair
     *         of groups.
     * @see setRules()
     */
    public Set<MonographEntryGroupPairRule> getRules() {
        return rules;
    }

    /**
     * Sets the set of MonographEntryGroupPairRules that belong to this pair of
     * groups. For Hibernate use.
     * @param newVal the set of MonographEntryGroupPairRules associated with
     *        this pair of groups.
     * @see getRules()
     */
    public void setRules(Set<MonographEntryGroupPairRule> aSet) {
        rules = aSet;
    }
    
    /**
     * Gets the second group of MonographEntries to be compared.
     * @return the second group of MonographEntries to be compared.
     * @see setSecondMonographEntryGroup()
     */
    public Set<MonographEntry> getSecondMonographEntryGroup() {
        return secondMonographEntryGroup;
    }

    /**
     * Sets the second group of MonographEntries to be compared.
     * For Hibernate use.
     * @param newVal the second group of MonographEntries to be compared.
     * @see getSecondMonographEntryGroup()
     */
    public void setSecondMonographEntryGroup(Set<MonographEntry> newVal) {
        secondMonographEntryGroup = newVal;
    }

    /**
     * Matches the rules against the passed parameters and populates matchedRules
     * with the result.
     * @param selectedMonographEntries the set of MonographEntries associated
     *        with the Product being evaluated.
     */
    public void matchRules(Set<MonographEntry> selectedMonographEntries) {
        if (rules != null && rules.size() > 0) {
            int numberSelectedFirstGroup = 0;
            int numberSelectedSecondGroup = 0;
            
            if (selectedMonographEntries != null 
                && selectedMonographEntries.size() > 0) {
                Set<MonographEntry> intersection = new HashSet<MonographEntry>(
                                    getFirstMonographEntryGroup());

                intersection.retainAll(selectedMonographEntries);
                numberSelectedFirstGroup = intersection.size();
 
                intersection = new HashSet<MonographEntry>(
                                   getSecondMonographEntryGroup());

                intersection.retainAll(selectedMonographEntries);
                numberSelectedSecondGroup = intersection.size();
            }
            
            matchedRules.clear();
            for (MonographEntryGroupPairRule rule : rules) {
                if (rule.isMatch(numberSelectedFirstGroup, numberSelectedSecondGroup)) {
                    matchedRules.add(rule);
                }
            }
        }
    }

    /**
     * This provides a list of the instance variable values for this object, and
     * is called by the PersistentObject's toString(). Intended to provide
     * useful debugging information. Subclasses should override this and add
     * their values to the end.
     */
    @Override
    public String getValuesAsString(){
        StringBuilder buffer = new StringBuilder();
        boolean isFirstItem;

        buffer.append(super.getValuesAsString());
        buffer.append(", firstMonographEntryGroup: ");
        if (getFirstMonographEntryGroup() != null){
            isFirstItem = true;
            buffer.append("[");
            for (MonographEntry entry : getFirstMonographEntryGroup()) {
                if (isFirstItem) {
                    isFirstItem = false;
                } else {
                    buffer.append(", ");
                }
                if (entry.getIngredient() != null) {
                    buffer.append(entry.getIngredient().getAuthorizedName());
                } else {
                    buffer.append("MonographEntry with no Ingredient");
                }
            }
            buffer.append("]");
        } else {
            buffer.append("null");
        }
        buffer.append(", secondMonographEntryGroup: ");
        if (getSecondMonographEntryGroup() != null){
            isFirstItem = true;
            buffer.append("[");
            for (MonographEntry entry : getSecondMonographEntryGroup()) {
                if (isFirstItem) {
                    isFirstItem = false;
                } else {
                    buffer.append(", ");
                }
                if (entry.getIngredient() != null) {
                    buffer.append(entry.getIngredient().getAuthorizedName());
                } else {
                    buffer.append("MonographEntry with no Ingredient");
                }
            }
            buffer.append("]");
        } else {
            buffer.append("null");
        }
        
        buffer.append(", rules: ");
        if (getRules() != null){
            isFirstItem = true;
            buffer.append("[");
            for (MonographEntryGroupPairRule rule : getRules()) {
                if (isFirstItem) {
                    isFirstItem = false;
                } else {
                    buffer.append(", ");
                }
                if (matchedRules.contains(rule)) {
                    buffer.append("MATCHED ");
                }
                buffer.append(rule.toString());
            }
            buffer.append("]");
        } else {
            buffer.append("null");
        }

        return buffer.toString();
    }
}
