package ca.gc.hc.nhpd.model.support;

/*******************************************************************************
 * An Interface implemented by objects that evaluate the relationship between
 * two numeric values. These are used when different numeric evaluation
 * operators need to be substituted into the same routine. This allows them to
 * be "plugged in", eliminating the need for additional "if" conditions.
 */
public interface Evaluator {
    /**
     * Evaluates the passed arguments and returns the relationship of the first
     * to the second within the context of the implementing class.
     * @return true if relationship of the first argument to the second is in
     *         keeping with the context of the implementing class.
     */
    public boolean evaluate(int firstArg, int secondArg);

    /**
     * Evaluates the passed arguments and returns the relationship of the first
     * to the second within the context of the implementing class.
     * @return true if relationship of the first argument to the second is in
     *         keeping with the context of the implementing class.
     */
    public boolean evaluate(Float firstArg, Float secondArg);
}
